import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-another-page',
  templateUrl: './another-page.component.html',
  styleUrls: ['./another-page.component.css']
})
export class AnotherPageComponent implements OnInit {
 
  modalTitle = "Simeon Profile"
  modalBody: any;
  constructor() { }


  ngOnInit(): void {
  }

  body(){
    this.modalBody = "sdfn gdg  gfg fg g fg fg fg f ggf gf gfgfg fg fg f";
    return this.modalBody;

  }

}
