import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  data = "Modal From Main Page"
  body:any;
  incomingID: any;
  constructor() { }

  ngOnInit(): void {
    this.data;
  }

  readMoreProfile(){
    this.body = "lorem dffofdn fdff dfdf dfdhfd fdfb dfdbf dvdfvn dfvjdv";
    // this.incomingID = response.id;
    return this.body;
  }

}
