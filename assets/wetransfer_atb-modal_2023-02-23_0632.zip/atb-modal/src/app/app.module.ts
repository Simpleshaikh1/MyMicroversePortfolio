import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NotificationComponent } from './Component/Modal/notification/notification.component';
import { MainComponent } from './Page/main/main.component';
import { ReadmoreComponent } from './Component/Modal/readmore/readmore.component';
import { AnotherPageComponent } from './Page/another-page/another-page.component';

@NgModule({
  declarations: [
    AppComponent,
    NotificationComponent,
    MainComponent,
    ReadmoreComponent,
    AnotherPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
