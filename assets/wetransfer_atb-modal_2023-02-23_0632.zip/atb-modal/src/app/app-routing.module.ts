import { AnotherPageComponent } from './Page/another-page/another-page.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './Page/main/main.component';

const routes: Routes = [
  {path: '', component: MainComponent},
  {path: 'readmore', component: AnotherPageComponent},
  {path: '**', component: MainComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
